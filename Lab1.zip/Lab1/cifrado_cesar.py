def cifrado_cesar(texto, corrimiento):
    abecedario = "abcdefghijklmnopqrstuvwxyz"
    texto_cifrado = ""
    for letra in texto:
        if letra in abecedario:
            posicion_letra = abecedario.find(letra)
            nueva_posicion = (posicion_letra + corrimiento) % len(abecedario)
            nueva_letra = abecedario[nueva_posicion]
            texto_cifrado += nueva_letra
        else:
            texto_cifrado += letra
    return texto_cifrado

texto = input("Ingrese el texto a cifrar: ")
corrimiento = int(input("Ingrese el corrimiento (1-26): "))
texto_cifrado = cifrado_cesar(texto, corrimiento)
print("--")
print("Texto cifrado: {}".format(texto_cifrado))

