import socket
import struct

def crear_paquete_icmp(tipo, codigo, id, secuencia, data):
    checksum = 0
    for i in range(0, len(data), 2):  
        checksum += (data[i] << 8) | data[i + 1] if i + 1 < len(data) else data[i]
    checksum = (checksum & 0xffff) ^ 0xffff

    cabecera_icmp = struct.pack("!BBHHH", tipo, codigo, id, secuencia, checksum)
    paquete = cabecera_icmp + data
    return paquete


def enviar_paquete_icmp(destino, paquete):

    sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_ICMP)
    sock.sendto(paquete, (destino, 0))

def cifrado_cesar(texto, corrimiento):

  abecedario = "abcdefghijklmnopqrstuvwxyz"
  texto_cifrado = ""
  for letra in texto:
    if letra in abecedario:
      posicion_letra = abecedario.find(letra)
      nueva_posicion = (posicion_letra + corrimiento) % len(abecedario)
      nueva_letra = abecedario[nueva_posicion]
      texto_cifrado += nueva_letra
    else:
      texto_cifrado += letra
  return texto_cifrado


# Función principal
def main():

    texto = input("Ingrese el texto a cifrar: ")
    corrimiento = int(input("Ingrese el corrimiento (1-26): "))
    texto_cifrado = cifrado_cesar(texto, corrimiento)
    print("--")
    print("Texto cifrado: {}".format(texto_cifrado))

    string = texto_cifrado

    destino = "127.0.0.1"  # Dirección IP de destino
    tipo = 8  # Tipo ICMP: Echo Request
    codigo = 0  # Código ICMP: Echo Request
    id = 0  # ID del paquete
    secuencia = 0  # Número de secuencia del paquete

    bytes_string = [ord(c) for c in string]

    for i, byte in enumerate(bytes_string):
        paquete = crear_paquete_icmp(tipo, codigo, id, secuencia + i, bytes([byte]))
        enviar_paquete_icmp(destino, paquete)
        print("Paquete enviado")

    
if __name__ == "__main__":
    main()